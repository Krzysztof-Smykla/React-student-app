# storage.py
from students.schema import Student

STUDENTS = [
    Student(id=1, first_name="John", last_name="Doe", email="adsof"),
    Student(id=2, first_name="Jane", last_name="Smith", email="asu0"),
    Student(id=3, first_name="Alex", last_name="Johnson", email="2iof"),
]
